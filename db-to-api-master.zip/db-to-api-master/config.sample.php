<?php

/*
Example configuration. All fields optional except the dataset name.

$args = array( 
            'name' => null,
            'username' => 'root',
            'password' => 'root',
            'server' => 'localhost',
            'port' => 3306,
            'type' => 'mysql',
            'table_blacklist' => array(),
            'column_blacklist' => array(),
);

register_db_api( 'dataset-name', $args );

*/
<?php

function register_db_api( $name, $args ) {
	
	$db_api = DB_API::get_instance();
	
	$db_api->register_db( $name, $args );
	
}

if ( !function_exists( 'shortcode_atts' ) ):

/**
 * Combine user attributes with known attributes and fill in defaults when needed.
 *
 * The pairs should be considered to be all of the attributes which are
 * supported by the caller and given as a list. The returned attributes will
 * only contain the attributes in the $pairs list.
 *
 * If the $atts list has unsupported attributes, then they will be ignored and
 * removed from the final returned list.
 *
 * @since 2.5
 *
 * @param array $pairs Entire list of supported attributes and their defaults.
 * @param array $atts User defined attributes in shortcode tag.
 * @return array Combined and filtered attribute list.
 */
function shortcode_atts($pairs, $atts) {
	$atts = (array)$atts;
	$out = array();
	foreach($pairs as $name => $default) {
		if ( array_key_exists($name, $atts) ) {
			$out[$name] = $atts[$name];
		}
		else {
			$out[$name] = $default;
		}
	}
	return $out;
}

endif;